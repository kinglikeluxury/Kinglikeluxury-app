import { useEffect, useState } from "react";

interface SplashScreenProps {
  onComplete: () => void;
}

export default function SplashScreen({ onComplete }: SplashScreenProps) {
  const [phase, setPhase] = useState<"in" | "hold" | "out">("in");

  useEffect(() => {
    const t1 = setTimeout(() => setPhase("hold"), 900);
    const t2 = setTimeout(() => setPhase("out"), 2600);
    const t3 = setTimeout(() => onComplete(), 3400);
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); };
  }, [onComplete]);

  return (
    <>
      <style>{`
        @keyframes kl-fade-in {
          from { opacity: 0; transform: scale(0.92); }
          to   { opacity: 1; transform: scale(1); }
        }
        @keyframes kl-glow-pulse {
          0%   { filter: drop-shadow(0 0 0px rgba(59,202,196,0)); }
          40%  { filter: drop-shadow(0 0 18px rgba(59,202,196,0.55)); }
          100% { filter: drop-shadow(0 0 8px rgba(59,202,196,0.2)); }
        }
        @keyframes kl-shimmer {
          0%   { background-position: -200% center; }
          100% { background-position: 200% center; }
        }
        @keyframes kl-text-in {
          from { opacity: 0; letter-spacing: 0.25em; }
          to   { opacity: 1; letter-spacing: 0.35em; }
        }
        @keyframes kl-sub-in {
          from { opacity: 0; }
          to   { opacity: 1; }
        }
        @keyframes kl-dots {
          0%, 100% { opacity: 0.3; }
          50%       { opacity: 0.8; }
        }
        .kl-crown {
          animation: kl-fade-in 0.85s cubic-bezier(0.22,1,0.36,1) forwards;
          opacity: 0;
        }
        .kl-crown.hold {
          animation: kl-fade-in 0.85s cubic-bezier(0.22,1,0.36,1) forwards,
                     kl-glow-pulse 1.4s ease-in-out forwards;
        }
        .kl-brand-name {
          animation: kl-text-in 0.9s cubic-bezier(0.22,1,0.36,1) 0.4s forwards;
          opacity: 0;
        }
        .kl-brand-name.shimmer {
          background: linear-gradient(90deg, #005476 30%, #3bcac4 50%, #005476 70%);
          background-size: 200% auto;
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          animation: kl-text-in 0.9s cubic-bezier(0.22,1,0.36,1) 0.4s forwards,
                     kl-shimmer 2.0s linear 1.0s 1;
        }
        .kl-subtitle {
          animation: kl-sub-in 0.7s ease-out 0.8s forwards;
          opacity: 0;
        }
        .kl-dot {
          animation: kl-dots 1.5s ease-in-out infinite;
        }
        .kl-dot:nth-child(2) { animation-delay: 0.5s; }
        .kl-dot:nth-child(3) { animation-delay: 1.0s; }
        .kl-divider {
          animation: kl-sub-in 0.7s ease-out 1.1s forwards;
          opacity: 0;
        }
        .kl-splash-wrap {
          transition: opacity 0.75s cubic-bezier(0.4,0,0.2,1);
        }
      `}</style>

      <div
        className="kl-splash-wrap fixed inset-0 z-[9999] flex flex-col items-center justify-center bg-white"
        style={{ opacity: phase === "out" ? 0 : 1, pointerEvents: phase === "out" ? "none" : "auto" }}
      >
        {/* Kinglike Luxury logo — transparent PNG, no white padding */}
        <div
          className={`kl-crown${phase !== "in" ? " hold" : ""}`}
          style={{ width: "min(78vw, 560px)" }}
        >
          <img
            src="/kinglike-logo-clean.png"
            alt="Kinglike Luxury"
            style={{ width: "100%", height: "auto", display: "block" }}
            draggable={false}
          />
        </div>
      </div>
    </>
  );
}
